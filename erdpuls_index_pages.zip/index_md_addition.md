---
# PASTE THIS BLOCK INTO YOUR EXISTING index.md
# Add the section below wherever you want the link to appear,
# for example near the bottom before any footer content.
---

## 📚 Open Educational Resources

Browse the full OER document repository — learning guides, soil science materials,
BNE quality frameworks, pattern discovery toolkits, and more, organized by language
and topic.

➡️ **[Open the OER Repository Index](/Pattern_Language_of_Place/)**

---
